module Examples.QuickCheckTest where
import Test.QuickCheck
import Data.List
 
qsort :: [Int] -> [Int]
qsort [] = []
idEmpProp xs = qsort xs == qsort (qsort xs)
revProp xs = qsort xs == qsort (reverse xs)
modelProp xs = qsort xs == sort xs