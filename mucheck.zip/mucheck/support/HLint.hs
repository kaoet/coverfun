-- Use the standard hint files
import "hint" HLint.Default
import "hint" HLint.Builtin.All

-- Tricky to remove duplication
ignore "Eta reduce"

