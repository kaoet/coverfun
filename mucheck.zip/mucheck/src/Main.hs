module Main where
import System.Environment (getArgs)

import Data.Maybe
import Language.Haskell.Exts
import Test.MuCheck
import Test.MuCheck.Mutation
import Test.MuCheck.Config
import Test.MuCheck (mucheck)
import Test.MuCheck.TestAdapter.AssertCheckAdapter
import Test.MuCheck.TestAdapter
import Test.MuCheck.Utils.Print

{-
main :: IO ()
main = do
  val <- getArgs
  case val of
    ("-h" : _ ) -> help
    ("-tix" : tix: file: _ ) -> do (msum, _tsum) <- mucheck (toRun file :: AssertCheckRun) tix
                                   print msum
    (file : _args) -> do (msum, _tsum) <- mucheck (toRun file :: AssertCheckRun) []
                         print msum
    _ -> error "Need function file [args]\n\tUse -h to get help"

help :: IO ()
help = putStrLn $ "mucheck function file [args]\n" ++ showAS ["E.g:",
       " mucheck [-tix <file.tix>] Examples/AssertCheckTest.hs",""]
-}

hello = hello + 1

main :: IO ()
main = do
    [file] <- getArgs
    let config = defaultConfig{maxNumMutants=200,doMutatePatternMatches=0.5,doMutateValues=0.5}
    (len, mutants) <- genMutantsWith config file ""
    let out = map (\m -> case m of Mutant code typ _ -> "[" ++ show code ++ "," ++ show (show typ) ++ "]") (take 200 mutants)
    putStr $ unlines out

{-
main = do
    [file] <- getArgs
    mod@(Module a (ModuleName moduleName) c d e imports decls) <- getASTFromFile file
    let filteredDecls = filter isNotType decls
        newImp = case importTypesIn True mod of
                    Nothing -> imports
                    Just x -> x:imports
        newMod = Module a (ModuleName $ moduleName++"_mut") c d e newImp filteredDecls
    putStr $ prettyPrint newMod
-}
{-
main = do
    [file] <- getArgs
    Module a b c d exports imports decls <- getASTFromFile file
    let newExp = case exports of
            Nothing -> exports
            Just expLst -> Just $ typeExps ++ otherExps
              where typeNames = map fromJust $ filter isJust $ map getDataTypes decls
                    typeExps = map (EThingAll . UnQual) typeNames
                    otherExps = expLst
        newMod = Module a b c d newExp imports decls
    putStrLn $ prettyPrint newMod
-}
{-
main = do
    [file] <- getArgs
    Module _ _ _ _ _ _ decls <- getASTFromFile file
    putStr $ unlines [ show (extractName name,l,c,isFn) | d <- decls, (name, SrcLoc _ l c, isFn) <- mergeRange $ funcRange d]
-}
extractName :: Name -> String
extractName (Ident n) = n
extractName (Symbol n) = n

mergeRange :: [(Name, SrcLoc, Bool)] -> [(Name, SrcLoc, Bool)]
mergeRange ((x, loc, True):(y, _,True):xs) | x == y = mergeRange ((x, loc, True):xs)
mergeRange (x:xs) = x:mergeRange xs
mergeRange [] = []

funcRange :: Decl -> [(Name, SrcLoc, Bool)]
funcRange (FunBind (Match loc name _ _ _ _ :xs)) = (name, loc, True):funcRange (FunBind xs)
funcRange (FunBind []) = []
funcRange (PatBind loc (PVar name) _ _ ) = [(name, loc, True)]
funcRange (TypeDecl loc name _ _) = [(name, loc, False)]
funcRange (TypeFamDecl loc name _ _) = [(name, loc, False)]
funcRange (ClosedTypeFamDecl loc name _ _ _) = [(name, loc, False)]
funcRange (DataDecl loc _ _ name _ _ _) = [(name, loc, False)]
funcRange (GDataDecl loc _ _ name _ _ _ _) = [(name, loc, False)]
funcRange (DataFamDecl loc _ name _ _) = [(name, loc, False)]
funcRange (TypeInsDecl loc _ _) = [(Ident "", loc, False)]
funcRange (DataInsDecl loc _ _ _ _) = [(Ident "", loc, False)]
funcRange (GDataInsDecl loc _ _ _ _ _) = [(Ident "", loc, False)]
funcRange (ClassDecl loc _ name _ _ _) = [(name, loc, False)]
funcRange (InstDecl loc a b c d e (InsDecl decl: xs)) = funcRange decl ++ funcRange (InstDecl loc a b c d e xs)
funcRange (InstDecl loc a b c d e (_:xs)) = funcRange (InstDecl loc a b c d e xs)
funcRange (InstDecl _ _ _ _ _ _ []) = []
funcRange (DerivDecl loc _ _ _ _ _) = [(Ident "", loc, False)]
funcRange (InfixDecl loc _ _ _) = [(Ident "", loc, False)]
funcRange (DefaultDecl loc _ ) = [(Ident "", loc, False)]
funcRange (SpliceDecl loc _) = [(Ident "", loc, False)]
funcRange (TypeSig loc names _) = map (\n -> (n, loc, False)) names
funcRange (ForImp loc _ _ _ name _) = [(name, loc, False)]
funcRange (ForExp loc _ _ name _) = [(name, loc, False)]
funcRange (RulePragmaDecl loc _) = [(Ident "", loc, False)]
funcRange (DeprPragmaDecl loc _) = [(Ident "", loc, False)]
funcRange (WarnPragmaDecl loc _) = [(Ident "", loc, False)]
funcRange (InlineSig loc _ _ _) = [(Ident "", loc, False)]
funcRange (InlineConlikeSig loc  _ _) = [(Ident "", loc, False)]
funcRange (SpecSig loc _ _ _) = [(Ident "", loc, False)]
funcRange (SpecInlineSig loc _ _ _ _) = [(Ident "", loc, False)]
funcRange (InstSig loc _ _ _ _) = [(Ident "", loc, False)]
funcRange (AnnPragma loc _) = [(Ident "", loc, False)]
funcRange (MinimalPragma loc _) = [(Ident "", loc, False)]


getASTFromFile filename = do
    ret <- parseFile filename
    case ret of
        ParseOk m -> return m
        _ -> do
            ret <- parseFileWithMode (defaultParseMode { fixities = Just [] }) filename
            return $ fromParseResult ret

isNotType :: Decl -> Bool
isNotType (TypeDecl _ _ _ _) = False
isNotType (TypeFamDecl _ _ _ _) = False
isNotType (ClosedTypeFamDecl _ _ _ _ _) = False
isNotType (DataDecl _ _ _ _ _ _ _) = False
isNotType (GDataDecl _ _ _ _ _ _ _ _) = False
isNotType (DataFamDecl _ _ _ _ _) = False
isNotType (ClassDecl _ _ _ _ _ _) = False
isNotType (InstDecl _ _ _ _ _ _ _) = False
isNotType _ = True

{-
main = do
    [file] <- getArgs
    mod <- getASTFromFile file
    case importTypesIn False mod of
        Nothing -> return ()
        Just imp -> putStrLn $ prettyPrint imp
-}
importTypesIn :: Bool -> Module -> Maybe ImportDecl
importTypesIn allConstructors (Module _ (ModuleName moduleName) _ _ exports imports decls) =
    if shouldImport == [] then Nothing else Just newImp
    where
        shouldImport = case exports of
                           Nothing ->
                             map (IThingAll . fromJust) $
                             filter isJust $
                             map getDataTypes decls
                           Just expLst ->
                             map fromJust $
                             filter isJust $
                             map (\exp ->
                               case exp of
                                   EAbs (UnQual x) -> Just $ if allConstructors then IThingAll x else IAbs x
                                   EThingAll (UnQual x) -> Just $ IThingAll x
                                   EThingWith (UnQual x) y -> Just $ if allConstructors then IThingAll x else IThingWith x y
                                   _ -> Nothing)
                               expLst
        newImp = ImportDecl (SrcLoc "" 0 0) (ModuleName moduleName) False False False Nothing Nothing $ Just (False, shouldImport)

getDataTypes :: Decl -> Maybe Name
getDataTypes (TypeDecl _ name _ _) = Just name
getDataTypes (TypeFamDecl _ name _ _) = Just name
getDataTypes (ClosedTypeFamDecl _ name _ _ _) = Just name
getDataTypes (DataDecl _ _ _ name _ _ _) = Just name
getDataTypes (GDataDecl _ _ _ name _ _ _ _) = Just name
getDataTypes (DataFamDecl _ _ name _ _) = Just name
getDataTypes (ClassDecl _ _ name _ _ _) = Just name
getDataTypes _ = Nothing
