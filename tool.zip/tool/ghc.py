import subprocess

def compile(root, hsfiles, binary, hpc=False, main=None):
    args = ['/usr/bin/ghc', '-w']
    if hpc:
        args += ['-fhpc']
    if main:
        args += ['-main-is', main]
    args += hsfiles
    args += ['-o', binary]
    
    try:
        with subprocess.Popen(args,cwd=root) as p:
            if p.wait() != 0:
                return False
    except Exception as e:
        raise Exception('compile failed') from e
    return True
