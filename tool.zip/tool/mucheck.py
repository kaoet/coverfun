import os.path
import subprocess
import shutil
import random
import bisect

import haskell

def getMutantFn(ranges, origLines, mutLines):
    ridx = -1
    for i in range(min(len(origLines), len(mutLines))):
        while ridx + 1 < len(ranges) and ranges[ridx+1][1]<=i + 1:
            ridx+=1
        if origLines[i] != mutLines[i]:
            if ridx >= 0 and ranges[ridx][3]:
                return ranges[ridx][0]+'@'+str(ranges[ridx][1])+':'+str(ranges[ridx][2])
            else:
                print('Unknown mutant')
                return ""
    print('Identical mutant')
    return None

def generateFor(oldroot, newroot, hs):
    with open(os.path.join(oldroot, hs)) as f:
        origLines = f.read().split('\n')
    
    ranges = subprocess.check_output(['funcRange', os.path.join(oldroot, hs)]).decode().split('\n')
    ranges = [eval(r) for r in ranges if r]
    ranges = sorted(ranges, key=lambda r:r[1])
    
    moduleName = haskell.getModuleName(os.path.join(oldroot, hs))
    lines = subprocess.check_output(['mucheck', os.path.join(oldroot, hs)]).decode('utf8').split('\n')
    result = [eval(x) for x in lines if x]
    
    mutants = []
    for i in range(len(result)):
        content = result[i][0]
        fn = getMutantFn(ranges, origLines, content.split('\n'))
        if fn is None:
            continue
        
        foo, bar = os.path.splitext(hs)
        newname = foo+'_' +  str(i) + bar
        parent_dir = os.path.dirname(os.path.join(newroot, newname))
        if not os.path.exists(parent_dir):
            os.makedirs(parent_dir)
        with open(os.path.join(newroot, newname), 'w') as f:
            f.write(content)
        mutants.append({
            'original': hs,
            'module': moduleName,
            'mutant': os.path.join(newroot, newname),
            'type': result[i][1],
            'fn': fn
        })
    return mutants

