#!/usr/bin/env python3

import os
import os.path
import re
import shutil
import subprocess
import random
import functools
import itertools
import time
import csv

import fs
import haskell
import ghc
import hpc
import parallel
import coverage

"""
Assertion coverage
"""

WORK_DIR="/home/kaoet/tmp"
RESULT_ROOT='/data/result11'
CODE_ROOT='/data/result10'

def lex(output):
	if "(),[]".find(output[0]) != -1:
		return (output[0], output[1:])
	elif "\"'".find(output[0]) != -1:
		i = 1
		while i < len(output) and output[i] != output[0]:
		    i += 1
		if i < len(output):
			return (output[:i+1], output[i+1:])
		else:
			return (output, [])
	elif output[0] == ' ':
		i = 1
		while i < len(output) and output[i] == ' ':
		    i+=1
		return (output[:i], output[i:])
	else:
		i = 1
		while i < len(output) and " []()'\",".find(output[i]) == -1:
		    i+=1
		return (output[:i], output[i:])
		
def parseE(tokens, inSpace):
	if len(tokens) == 0:
		return ([], [])
	
	components = []
	
	if "[(".find(tokens[0]) != -1:
		before = tokens[1:]
		closeSign = ")"
		if tokens[0] == "[":
			closeSign = "]"
		while len(before) > 0 and before[0] != closeSign:
			after = parseE(before, False)[1]
			components.append(''.join(before[:len(before)-len(after)]))
			if len(after) > 0 and after[0] == ",":
				before = after[1:]
			else:
				before = after
		
		if len(before) > 0:
			before = before[1:]
			if not inSpace and len(before) > 0 and before[0] == " ":
				return parseEE(before, ''.join(tokens[:len(tokens)-len(before)]))
			else:
				return (components, before)
		else:
			return (components, before)
	else:
		if not inSpace and len(tokens) > 1 and tokens[1] == " ":
			return parseEE(tokens[1:], tokens[0])
		else:
			return ([tokens[0]], tokens[1:])

def parseEE(tokens, first):
	components = [first]
	before = tokens
	while len(before) > 0 and before[0] == " ":
		before = before[1:]
		after = parseE(before, True)[1]
		components.append(''.join(before[:len(before)-len(after)]))
		before = after
	return (components, before)

def separateComponents(output):
	tokens = []
	while len(output) > 0:
		(token, output) = lex(output)
		tokens.append(token)
	return parseE(tokens, False)[0]
	
def recover_test_cases(root):
    cases = []
    for i in range(1000):
        if not os.path.exists(os.path.join(root, 'test cases', 'case_' + str(i) + '.txt')):
            break
        with open(os.path.join(root, 'test cases', 'case_' + str(i) + '.txt'), 'r') as f:
            m = re.match(r'(.*?)\((.*?)\.(.*?)\) (.*)', f.read())
        cur_case = {
            'id': i,
            'case': m.group(1),
            'module': m.group(2),
            'fn': m.group(3),
            'args': m.group(4)
        }
        with open(os.path.join(root, 'test cases', 'case_' + str(i) + '.answer'), 'r') as f:
            cur_case['answer'] = f.read()
        cases.append(cur_case)
    return cases       

def compileOriginal(root, hsfiles):
    if os.path.exists('/tmp/obj'):
        shutil.rmtree('/tmp/obj')
    shutil.copytree(os.path.join(root, 'src'), '/tmp/obj')
    if not ghc.compile('/tmp/obj', hsfiles, 'Main', hpc=True, main = 'Test_.main'):
        raise Exception('Cannot compile original source code')

def replay(typeImports, hsfiles, tickBoxes, case):
    def test_and_measure(expr):
        def inner(tmpdir):
            shutil.rmtree(tmpdir)
            shutil.copytree('/tmp/obj', tmpdir)
            
            haskell.generateTestModuleExpr(tmpdir, [expr], [case], typeImports)
            if not ghc.compile(tmpdir, hsfiles + ['Test_.hs'], 'Main', hpc=True, main='Test_.main'):
                print('COMPILE ERROR', expr)
                return None
            
            ret, utime = haskell.runTest(os.path.join(tmpdir, 'Main'), tmpdir)
            if ret is None:
                return None
                
            [answer] = ret
            if answer is None:
                return None
            
            tixes = hpc.parseTIX(os.path.join(tmpdir, 'Main.tix'))
            return hpc.getHitBoxes(tickBoxes, tixes)
        return fs.withTempDir(inner)
        
    invokation = '(' + case['case'] + '(' + case['module'] + '.' + case['fn'] + ') ' + case['args'] + ')'
    
    result = []
    if case['answer'][0] == '[':
        for i in range(len(case['segments'])):
            ret = test_and_measure('Prelude.show (' + invokation + ' !! ' + str(i) + ')')
            result.append(ret)
    elif case['answer'][0] == '(':
        for i in range(len(case['segments'])):
            pattern = '(' + '_,' * i + 'value@_' + ',_' * (len(case['segments']) - i - 1) + ')'
            ret = test_and_measure('Prelude.show (case ' + invokation + ' of ' + pattern + ' -> value)')
            result.append(ret)
    else:
        pattern = case['segments'][0] + ' _' * (len(case['segments']) - 1)
        ret = test_and_measure('Prelude.show (case ' + invokation + ' of ' + pattern + ' -> "")')
        if ret is None:
            return None
        result.append(ret)
        for i in range(1, len(case['segments'])):
            pattern = case['segments'][0] + ' _' * (i-1) + ' value@_' + ' _' * (len(case['segments']) - i - 1)
            ret = test_and_measure('Prelude.show (case ' + invokation + ' of ' + pattern + ' -> value)')
            result.append(ret)
    
    case['assertion_coverage'] = result
    return case

def save_assertion_coverage(root, test_cases):
    for case in test_cases:
        for i in range(len(case['assertion_coverage'])):
            cov = case['assertion_coverage'][i]
            if cov:
                with open(os.path.join(root, 'case_' + str(case['id']) + '_' + str(i) + '.statement'), 'w') as f:
                    for h in coverage.statement(cov):
                        f.write(h['unique'] + '\n')
                with open(os.path.join(root, 'case_' + str(case['id']) + '_' + str(i) + '.branch'), 'w') as f:
                    for h in coverage.branch(cov):
                        f.write(h['unique'] + '\n')
                with open(os.path.join(root, 'case_' + str(case['id']) + '_' + str(i) + '.expression'), 'w') as f:
                    for h in coverage.expression(cov):
                        f.write(h['unique'] + '\n')
                with open(os.path.join(root, 'case_' + str(case['id']) + '_' + str(i) + '.function'), 'w') as f:
                    f.write('\n'.join(coverage.function(cov)))

def process(root):
    if os.path.exists(WORK_DIR):
        shutil.rmtree(WORK_DIR)
    os.mkdir(WORK_DIR)
    
    print('finding hs files')
    hsfiles = fs.findAllHsFiles(os.path.join(root, 'src'))
    
    print('collecting data types')
    typeImports = ''.join([haskell.importTypes(os.path.join(root,'src',hs)) for hs in hsfiles])
    
    print('pre-compile')
    compileOriginal(root, hsfiles)
    
    print('getTickBoxes')
    modules = [haskell.getModuleName(os.path.join(root, 'src', hs)) for hs in hsfiles]
    tickBoxes = {m: hpc.parseMIX(os.path.join('/tmp/obj', '.hpc', m+'.mix'), m) for m in modules}
    
    print('Recovering Test Cases')
    test_cases = []
    for case in recover_test_cases(root):
        comps =  separateComponents(case['answer'])
        if len(comps) > 1:
            case['segments'] = comps
            test_cases.append(case)
    
    test_cases, failed_cases = parallel.do(functools.partial(replay, typeImports, hsfiles, tickBoxes), test_cases, len(test_cases))
    
    print('saving assertion coverage')
    save_assertion_coverage(WORK_DIR, test_cases)

PROG_NAMES = [
    'linear', 'hidden', 'bspt', 'grep', 'hpg', 'infer', 'mkhprog', 'veritas',
    'anna','cacheprof','fem','fluid','fulsom',
    'gamteb','gg','lift','maillist','parser','pic',
    'prolog','reptile','rsa','scs','symalg'
    #'compress','compress2','ebnf2ps','HMMS','PolyGP','rx'
]

for progName in PROG_NAMES:
    if os.path.exists(os.path.join(RESULT_ROOT, progName)):
        print(progName, 'skipped')
        continue
    print(progName,'start processing')
    process(os.path.join(CODE_ROOT, progName))
    shutil.move(WORK_DIR, os.path.join(RESULT_ROOT, progName))
