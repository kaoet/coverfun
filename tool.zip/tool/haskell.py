import re
import subprocess
import os.path

TEST_MAIN_TEMPLATE = """
main = do
  results <- mapM handle [{{exprs}}]
  putStr $ "[" ++ (LST__.intercalate ","  $ map interpret results) ++ "]"
  where handle :: String -> IO (Maybe String)
        handle e = TLE__.timeout 1000000 $ RE__.catch (RE__.evaluate $ DS__.force $ take 1024 e) catcher
        catcher :: RE__.SomeException -> IO String
        catcher e | show e == "<<timeout>>" = RE__.throwIO e
        catcher _                           = return "<<error>>"
        interpret :: Maybe String -> String
        interpret Nothing = "None"
        interpret (Just "<<error>>") = "None"
        interpret (Just s) = show s
"""

def convertTab(line):
    s = ''
    for c in line:
        if c == '\t':
            s += ' '
            while len(s) % 8 != 0:
                s+=' '
        else:
            s+=c
    return s

def preprocess(path):
    with open(path,'r',encoding='latin1') as f:
        content = f.read()
        
    content = '\n'.join([convertTab(l) for l in content.split('\n')])
    if not re.search(r'^\s*module\b',content,flags=re.MULTILINE):
        content = 'module Main where\n' + content

    with open(path,'w') as f:
        f.write(content)
    content = subprocess.check_output(['exportAllTypes', path])
    with open(path, 'wb') as f:
        f.write(content)
"""
def removeExportList(path):
    with open(path,'r') as f:
        content = f.read()
    content = re.sub(r'^\s*module\s+([a-zA-Z0-9.]+)\s*\(.*\)\s*where','module \\1 where',content,flags=re.MULTILINE|re.DOTALL)
    with open(path,'w') as f:
        f.write(content)     


def addImport(path, imports):
    imports = '\n'.join(['import qualified '+i[0]+' as '+i[1] for i in imports])
    with open(path,'r') as f:
        content = f.read()
    content = re.sub(r'(^\s*module [a-zA-Z0-9.]+ where\s*)', '\\1' + imports + '\n', content,flags=re.MULTILINE)
    with open(path,'w') as f:
        f.write(content)  
"""

def importTypes(f):
    print('importTypes', f)
    return subprocess.check_output(['importTypes', f]).decode('utf-8')

def findFuncNames(f):
    return eval(subprocess.check_output(['funcnames',f]))

def getModuleName(path):
    with open(path,'r') as f:
        content = f.read()
    m = re.search(r'^\s*module\s+([_a-zA-Z0-9.]+)', content, flags=re.MULTILINE)
    if m:
        return m.group(1)
    else:
        return 'Main'

def generateTestModule(root, cases, typeImports):
    exprs = []
    for c in cases:
        exprs.append('Prelude.show (' + c['case'] + '(' + c['module'] + '.' + c['fn'] + ') ' + c['args'] + ')')
    return generateTestModuleExpr(root, exprs, cases, typeImports)

def generateTestModuleExpr(root, exprs, cases, typeImports):
    modules = set(c['module'] for c in cases)
    
    content = 'module Test_ where\n'
    content += 'import qualified Data.List as LST__\n'
    content += 'import qualified Control.Exception as RE__\n'
    content += 'import qualified System.Timeout as TLE__\n'
    content += 'import qualified Control.DeepSeq as DS__\n'
    content += 'import Data.Array\n'
    content += typeImports
    for m in modules:
        content += 'import ' + m + ' hiding (main)\n'
    content += TEST_MAIN_TEMPLATE.replace('{{exprs}}', ','.join(exprs))
    with open(os.path.join(root, 'Test_.hs') ,'w') as f:
        f.write(content)

class MyPopen(subprocess.Popen):
    def wait_with_usage(self):
        assert self.returncode is None
        pid, sts, usage = subprocess._eintr_retry_call(os.wait4, self.pid, 0)
        self._handle_exitstatus(sts)
        return (self.returncode, usage)

def runTest(binary, root, args=[]):
    try:
        with MyPopen([binary] + args, stdout=subprocess.PIPE, cwd=root) as p:
            status, usage = p.wait_with_usage()
            if status != 0:
                raise Exception("RunTest returned" + str(status))
            return (eval(p.stdout.read()), usage.ru_utime)
    except Exception as e:
        print('WARNING! runTest failed!', e)
        return (None, None)
