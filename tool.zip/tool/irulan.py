import os
import subprocess
import re

IRULAN_ARGS = [
    '-a', '--maximumRuntime=10',
    '--enable-vco', '--enable-case-statements', '--enable-case-arguments',
    '--ints=[1,0,2]','--integers=[1,0,2]', r"--chars=['<','>','[','-',']']", '--floats=[-1,0,0.5,1,2]','--doubles=[-1,0,0.5,1,2]',
    #'--ghc-options=-fforce-recomp -fhpc', '--hpc-testsuite',
    '--full-testsuite=test.tst',
];

def sanitize(s):
    s = s.replace('(: ', '((:) ');
    s = re.sub(r'\?\d*', 'undefined',s)
    s = s.replace(' * ',' () ')
    s = re.sub(r'-([0-9.]+)',r'(-\1)', s)
    return s
    
def removeDollar(s):
    p = 0
    result = ''
    while p < len(s):
        if s[p] == ' ':
            p += 1
            continue
        if s[p] == '(':
            q = p+1
            nest = 1
            hasDollar = False
            while q < len(s) and nest > 0:
                if s[q] == '(':
                    nest += 1
                    q += 1
                elif s[q] == ')':
                    nest -= 1
                    q += 1
                elif s[q] == '$' and (s[q-1] == '(' or s[q-1] == ' ' or s[q-1] == ','):
                    hasDollar = True
                    q += 1
                else:
                    q += 1
            if nest > 0:
                print('bad nesting parenthese')
                return None
            if not hasDollar:
                result += ' ' + s[p:q]
            p = q
        else:
            q = p
            hasDollar = False
            while q < len(s) and s[q] != ' ':
                if s[q] == '$' and (s[q-1] == '(' or s[q-1] == ' ' or s[q-1] == ','):
                    hasDollar = True
                q += 1
            if not hasDollar:
                result += ' ' + s[p:q]
            p = q
    return result

def parseTSA(s):
    testCases = []
    for l in s.split('\n'):
        m = re.match(r'A#\s+((?:case )*)\s*(\S+)(.*)\s+==> (.*)',l)
        if m:
            result = m.group(4)
            if result.startswith('!'):
                continue
            args = removeDollar(sanitize(m.group(3)))
            if args is not None:
                testCases.append({
                    'case': m.group(1),
                    'fn': m.group(2),
                    'args': re.sub(r' +',' ', args).strip()
                })
    return testCases;
    
def generate(src, modulename):
    direc = os.path.dirname(src)
    try:
        with subprocess.Popen(['irulan'] + IRULAN_ARGS + ['source', modulename], cwd=direc, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL) as p:
            if p.wait()!=0:
                raise Exception("irulan returned non-zero")
    except Exception as e:
        raise Exception('irulan failure') from e
    
    tsa = subprocess.check_output(['irulan', 'tsa', os.path.join(direc,'test.tst')]).replace(b'\x1b[0m',b'').replace(b'\x1b[33m',b'').decode('utf8')
    cases = parseTSA(tsa)
    for c in cases:
        c['module'] = modulename
    return cases
