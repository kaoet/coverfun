#!/usr/bin/env python3

__author__ = "Cheng Yufeng"

CODE_ROOT = '/home/kaoet/nofib/real/'
RESULT_ROOT = '/data/result11'
WORK_DIR = '/home/kaoet/tmp/'
MUTANT_LIMIT = 1000
TEST_CASE_LIMIT = 1000

import os
import os.path
import re
import shutil
import subprocess
import random
import functools
import itertools
import csv

import irulan
import haskell
import mucheck
import fs
import ghc
import hpc
import coverage
import parallel
import util

def genCases(hsfiles):
    def inner(tmpdir):
        fs.copyAll(hsfiles, os.path.join(WORK_DIR, 'src'), tmpdir)
        cases = []
        for hs in hsfiles:
            print('generating test cases for',hs)
            hsInTemp = os.path.join(tmpdir, hs)
            cases.extend(irulan.generate(hsInTemp, haskell.getModuleName(hsInTemp)))
            shutil.move(os.path.join(tmpdir, 'test.tst'), os.path.join(WORK_DIR,hs.replace('/','.')+'.tst'))
        return cases
    return fs.withTempDir(inner)

def compileOriginal(hsfiles):
    fs.copyAll(hsfiles, os.path.join(WORK_DIR,'src'), '/tmp/obj')
    if not ghc.compile('/tmp/obj', hsfiles, 'Main', hpc=True, main = 'Test_.main'):
        raise Exception('Cannot compile original source code')

def getTickBoxes(hsfiles):
    modules = [haskell.getModuleName(os.path.join(WORK_DIR, 'src', hs)) for hs in hsfiles]
    return {m: hpc.parseMIX(os.path.join('/tmp/obj', '.hpc', m+'.mix'), m) for m in modules}
      
def replaySome(hsfiles, typeImports, mutant, cases, tmpdir):
    shutil.rmtree(tmpdir)
    shutil.copytree('/tmp/obj',tmpdir)
    shutil.copy(mutant['mutant'], os.path.join(tmpdir, mutant['original']))
    
    haskell.generateTestModule(tmpdir, cases, typeImports)
    if not ghc.compile(tmpdir, hsfiles + ['Test_.hs'], 'Main', hpc=True, main='Test_.main'):
        return []
    ret, utime = haskell.runTest(os.path.join(tmpdir, 'Main'), tmpdir)
    if ret is None:
        return []
    if len(ret) != len(cases):
        raise Exception('Result count mismatch, should be', len(cases), 'but', len(ret)) 
    result = []
    for i in range(len(cases)):
        if ret[i] is None:
            result.append((cases[i]['id'], True, False, ''))
        else:
            result.append((cases[i]['id'], False, ret[i] == cases[i]['answer'] , ret[i]))
    return result

def replayMany(hsfiles, typeImports, cases, mutant):
    try:
        result = []
        for x in range(0, len(cases), 10):
            result.extend(fs.withTempDir(functools.partial(replaySome, hsfiles, typeImports, mutant, cases[x:x+10])))
            
        mutant['result'] = result
        return mutant
    except Exception as e:
        while True:
            print(e)
    
def replay(hsfiles, tickBoxes, typeImports, case):
    def inner(tmpdir):
        shutil.rmtree(tmpdir)
        shutil.copytree('/tmp/obj', tmpdir)
        
        haskell.generateTestModule(tmpdir, [case], typeImports)
        if not ghc.compile(tmpdir, hsfiles + ['Test_.hs'], 'Main', hpc=True, main='Test_.main'):
            return None
        
        ret, utime = haskell.runTest(os.path.join(tmpdir, 'Main'), tmpdir)
        if ret is None:
            return None
        [answer] = ret
        if answer is None:
            return None
        case['answer'] = answer
        case['utime'] = utime
        
        tixes = hpc.parseTIX(os.path.join(tmpdir, 'Main.tix'))
        case['hit'] = hpc.getHitBoxes(tickBoxes, tixes)
        
        return case
    return fs.withTempDir(inner)

def saveTestCases(cases):
    caseDir = os.path.join(WORK_DIR, 'test cases')
    os.mkdir(caseDir)
    
    for i in range(len(cases)):
        case = cases[i]
        with open(os.path.join(caseDir, 'case_'+str(i)+'.txt'), 'w') as f:
            f.write(case['case'] + '(' + case['module'] + '.' + case['fn']+ ') ' + case['args'])
        with open(os.path.join(caseDir, 'case_'+str(i)+'.answer'), 'w') as f:
            f.write(str(case['answer']))
        with open(os.path.join(caseDir, 'case_'+str(i)+'.utime'), 'w') as f:
            f.write(str(case['utime']))
        with open(os.path.join(caseDir, 'case_'+str(i)+'.expression'), 'w') as f:
            for h in coverage.expression(case['hit']):
                f.write(h['unique'] + '\n')
        with open(os.path.join(caseDir, 'case_'+str(i)+'.branch'), 'w') as f:
            for h in coverage.branch(case['hit']):
                f.write(h['unique'] + '\n')
        with open(os.path.join(caseDir, 'case_'+str(i)+'.statement'), 'w') as f:
            for h in coverage.statement(case['hit']):
                f.write(h['unique'] + '\n')
        with open(os.path.join(caseDir, 'case_'+str(i)+'.function'), 'w') as f:
            f.write('\n'.join(coverage.function(case['hit'])))

def coverageSumup(hsfiles, cases, typeImports):
    def inner(tmpdir):
        shutil.rmtree(tmpdir)
        shutil.copytree('/tmp/obj', tmpdir)

        for x in range(0,len(cases), 10):
            fs.remove(os.path.join(tmpdir, 'Test_.hi'))
            fs.remove(os.path.join(tmpdir, 'Test_.o'))
            fs.remove(os.path.join(tmpdir, 'Main'))
            haskell.generateTestModule(tmpdir, cases[x:x+10], typeImports)
            if not ghc.compile(tmpdir, hsfiles + ['Test_.hs'], 'Main', hpc=True, main='Test_.main'):
                raise Exception('Cannot compile original program with all test cases')
            results = haskell.runTest(os.path.join(tmpdir, 'Main'), tmpdir)
            if results is None or any([x is None for x in results]):
                raise Exception('Some test case failed when generating coverage report')
            hpc.removeModuleFromTix(os.path.join(tmpdir, 'Main.tix'), 'Test_')
        
        hpc.generateReport(os.path.join(tmpdir, 'Main.tix'), os.path.join(WORK_DIR, 'coverage'))
    fs.withTempDir(inner)

def saveAllCheckPoints(tickBoxes):
    boxes = [h for m in tickBoxes for h in tickBoxes[m]]
    with open(os.path.join(WORK_DIR, 'test cases', 'all.expression'), 'w') as f:
        for h in coverage.expression(boxes):
            if h['module'] != 'Test_':
                f.write(h['unique'] + '\n')
    with open(os.path.join(WORK_DIR, 'test cases', 'all.branch'), 'w') as f:
        for h in coverage.branch(boxes):
            if h['module'] != 'Test_':
                f.write(h['unique'] + '\n')
    with open(os.path.join(WORK_DIR, 'test cases', 'all.statement'), 'w') as f:
        for h in coverage.statement(boxes):
            if h['module'] != 'Test_':
                f.write(h['unique'] + '\n')

def generateMutants(hsfiles):
    fs.makeEmptyDir('/tmp/mutants')
    mutants, failed = parallel.do(functools.partial(mucheck.generateFor, os.path.join(WORK_DIR, 'src'), '/tmp/mutants'), hsfiles, len(hsfiles))
    return [y for x in mutants for y in x]

def saveMutants(mutants):
    for mu in mutants:
        newLoc = os.path.join(WORK_DIR,'mutants',os.path.relpath(mu['mutant'], '/tmp/mutants'))
        if not os.path.exists(os.path.dirname(newLoc)):
            os.makedirs(os.path.dirname(newLoc))
        os.rename(mu['mutant'], newLoc)
        with open(newLoc+'.fn','w') as f:
            if mu['fn'] == "":
                f.write('')
            else:
                f.write(mu['module'] + '.' + mu['fn'])
        mu['mutant'] = newLoc
    return mutants

def removeDuplicatedCases(cases):
    result = []
    calls = set()
    for c in cases:
        call = c['case'] + '(' + c['module'] + '.' + c['fn']+ ') ' + c['args']
        if call not in calls:
            calls.add(call)
            result.append(c)
            
    return result

def process(srcLoc):
    fs.makeEmptyDir(WORK_DIR)
    os.chdir(WORK_DIR)
    
    print('finding hs files')
    hsfiles = fs.findAllHsFiles(srcLoc)
    print('hsfiles found:',hsfiles)
    
    print('copying to tmp directory')
    fs.copyAll(hsfiles, srcLoc, os.path.join(WORK_DIR, 'src'))
    
    for hs in hsfiles:
        print('preprocessing', hs)
        haskell.preprocess(os.path.join(WORK_DIR, 'src', hs))

    print('collecting data types')
    typeImports = ''.join([haskell.importTypes(os.path.join(WORK_DIR,'src',hs)) for hs in hsfiles])
    
    print('getting function names')
    allFuncs = []
    for hs in hsfiles:
        module = haskell.getModuleName(os.path.join(WORK_DIR, 'src', hs))
        allFuncs.extend([module+'.'+fn for fn in haskell.findFuncNames(os.path.join(WORK_DIR, 'src', hs))])
    allFuncs = set(allFuncs)
    
    print('compiling original source code for', srcLoc)
    compileOriginal(hsfiles)
    
    mutants = generateMutants(hsfiles)
    mutants = util.randomizeBy(mutants,lambda x:x['type'])
    print('total mutants', len(mutants))
    
    testCases = genCases(hsfiles)
    print('Irulan generated', len(testCases), 'test cases')
    testCases = removeDuplicatedCases(testCases)
    print('After unique,', len(testCases), 'test cases')
    testCases = util.randomizeBy(testCases, lambda x:x['module']+'.'+x['fn'])
    
    with open(os.path.join(WORK_DIR, 'irulan_not_tested.txt'), 'w') as f:
        for fn in allFuncs - set(t['module'] + '.' + t['fn'] for t in testCases):
            f.write(fn)
            f.write('\n')
    
    print('getting tick boxes')
    tickBoxes = getTickBoxes(hsfiles)
    
    testCases, failedTestCases = parallel.do(functools.partial(replay, hsfiles, tickBoxes, typeImports), testCases, TEST_CASE_LIMIT)
    print('after running, left test cases', len(testCases))
    with open(os.path.join(WORK_DIR, 'failed_to_replay.txt'), 'w') as f:
        for line in set(t['module']+'.'+t['fn']+'\n' for t in failedTestCases):
            f.write(line)
    
    if len(testCases) == 0:
        print('No test case left')
        return False
    for i in range(len(testCases)):
        testCases[i]['id'] = i
    
    print('saving test cases')
    saveTestCases(testCases)
    saveAllCheckPoints(tickBoxes)
    
    print('generating coverage report')
    coverageSumup(hsfiles, testCases, typeImports)
    
    mutants, failedMutants = parallel.do(functools.partial(replayMany, hsfiles, typeImports, testCases), mutants, MUTANT_LIMIT)
    print('after replay, left mutant', len(mutants))
    
    saveMutants(mutants)
    print('saving mutants')
    
    with open(os.path.join(WORK_DIR, 'result.csv'), 'w', newline='') as f:
        writer = csv.writer(f)
        writer.writerow(['mutant', 'case id', 'crashed', 'killed', 'output'])
        for mu in mutants:
            relativePath = os.path.relpath(mu['mutant'], os.path.join(WORK_DIR, 'mutants'))
            for r in mu['result']:
                caseId = r[0]
                crashed = r[1]
                killed = not r[2]
                output = r[3]
                writer.writerow([relativePath, caseId, 'yes' if crashed else 'no', 'yes' if killed else 'no', output])
        
    # cleaning
    shutil.rmtree('/tmp/obj')

PROG_NAMES = [
    'linear', 'hidden', 'bspt', 'grep', 'hpg', 'infer', 'mkhprog', 'veritas',
    'anna','cacheprof','fem','fluid','fulsom',
    'gamteb','gg','lift','maillist','parser','pic',
    'prolog','reptile','rsa','scs','symalg'
    #'compress','compress2','ebnf2ps','HMMS','PolyGP','rx'
]

for progName in PROG_NAMES:
    if os.path.exists(os.path.join(RESULT_ROOT, progName)):
        print(progName, 'skipped')
        continue
    print(progName,'start processing')
    process(os.path.join(CODE_ROOT, progName))
    shutil.move(WORK_DIR, os.path.join(RESULT_ROOT, progName))
        
    
