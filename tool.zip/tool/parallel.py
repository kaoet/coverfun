import multiprocessing
import queue

def do(fn, data, limit):
    mgr = multiprocessing.Manager()
    progress = mgr.Value('i', 0)
    total = mgr.Value('i', min(limit, len(data)))
    resultQ = mgr.Queue(maxsize=limit)
    failQ = mgr.Queue()
    
    with multiprocessing.Pool(multiprocessing.cpu_count(), initializer = init, initargs=(fn, resultQ, failQ, progress, total)) as pool:
        pool.map(worker, data, 1)
    
    result = []
    while not resultQ.empty():
        result.append(resultQ.get())
    failed = []
    while not failQ.empty():
        failed.append(failQ.get())
    return (result, failed)

def init(fn, resultQ, failQ, progress, total):
    global g_fn
    global g_resultQ
    global g_progress
    global g_total
    global g_failQ
    g_failQ = failQ
    g_fn = fn
    g_resultQ = resultQ
    g_progress = progress
    g_total = total

def worker(datum):
    if g_resultQ.full():
        return
    
    print('Progress:', g_progress.value, '/', g_total.value)
    g_progress.value+=1
    result = g_fn(datum)
    
    if result is not None:
        try:
            g_resultQ.put_nowait(result)
        except queue.Full:
            print('full detected')
    else:
        g_failQ.put(datum)
