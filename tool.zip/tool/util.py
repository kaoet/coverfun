import random
import itertools

def randomizeBy(data, key):
    data = sorted(data,key=key)
    
    byKey = dict()
    keys = set()
    for k, datum in itertools.groupby(data, key=key):
        tmp = list(datum)
        random.shuffle(tmp)
        byKey[k] = tmp
        keys.add(k)
    
    result = []
    for i in range(len(data)):
        k = random.choice(list(keys))
        tmp=byKey[k]
        result.append(tmp.pop())
        if not tmp:
            del byKey[k]
            keys.remove(k)
    return result

def editDistance(s1, s2):
    f = [j for j in range(len(s2) + 1)]
    g = [0 for j in range(len(s2) + 1)]
    
    for i in range(1, len(s1) + 1):
        f,g = g,f
        for j in range(len(s2) + 1):
            f[j] = g[j] + 1
            if j > 0:
                f[j] = min(f[j], f[j-1] + 1, g[j-1] + (1 if s1[i-1] != s2[j-1] else 0))
    return f[len(s2)]

def lcs(s1, s2):
    f = [0 for j in range(len(s2) + 1)]
    g = [0 for j in range(len(s2) + 1)]
    
    for i in range(1, len(s1) + 1):
        f,g = g,f
        for j in range(len(s2) + 1):
            if j == 0:
                f[j] = 0
            elif s1[i-1] == s2[j-1]:
                f[j] = g[j-1] + 1
            else:
                f[j] = max(f[j-1], g[j])
    return f[len(s2)]
