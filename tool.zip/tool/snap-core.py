#!/usr/bin/env python3
import os.path
import shutil

import fs
import haskell
import mucheck
import ghc
import hpc
import re
import coverage
import random
import functools
import subprocess
import xml.etree.ElementTree as ET
import csv
import parallel
import util

WORK_DIR = '/home/kaoet/tmp'
OBJ_DIR = os.path.join(WORK_DIR, 'src')
srcLoc = '/home/kaoet/unit/snap-core'
if os.path.exists(WORK_DIR):
   shutil.rmtree(WORK_DIR)
os.mkdir(WORK_DIR) 
os.chdir(WORK_DIR)

def parseResultXML(path):
    root = ET.ElementTree(file = path)
    ret = {}
    for case in root.iterfind('testcase'):
        ret[case.get('name')] = False if case.getchildren() else True
    return ret
            
def getTickBoxes():
    mixes = [f for f in os.listdir(os.path.join(WORK_DIR, 'src', 'test', '.hpc')) if f.endswith('.mix')]
    ret = {}
    for m in mixes:
        modulename = m[:-4]
        filepath = os.path.join(WORK_DIR, 'src', 'test', '.hpc', m)
        ret[modulename] = hpc.parseMIX(filepath, modulename)
    return ret

def runTests(root, tests):
    test_args = ['--select-tests='+t for t in tests]
    os.chdir(os.path.join(root, 'test'))
    try:
        with subprocess.Popen([executable(root), '--jxml=test.xml', '--hide-successes'] + test_args) as p:
            p.wait()
    except:
        return None
    if not os.path.exists(os.path.join(root, 'test', 'test.xml')):
        print('Cannot find test.xml')
        return None
    result = parseResultXML(os.path.join(root, 'test', 'test.xml'))
    if len(tests) != len(result):
        raise Exception('Length not match')
    return [result[t] for t in tests]

def replay(tickBoxes, case):
    tmpdir = fs.makeTempDir('/tmp')
    shutil.rmtree(tmpdir)
    shutil.copytree(OBJ_DIR, tmpdir)
    
    try:
        [succ] = runTests(tmpdir, [case])
        if not succ:
            print('original test suite not success', case)
            return None
        
        tixes = hpc.parseTIX(os.path.join(tmpdir, 'test', 'testsuite.tix'))
        return hpc.getHitBoxes(tickBoxes, tixes)
    finally:
        shutil.rmtree(tmpdir)

def saveHits(hits):
    caseDir = os.path.join(WORK_DIR, 'test cases')
    os.mkdir(caseDir)
    
    for i in range(len(hits)):
        print('saving hits for', i)
        hit = hits[i]
        with open(os.path.join(caseDir, 'case_'+str(i)+'.branch'), 'w') as f:
            for h in coverage.branch(hit):
                if h['module'] == 'Main':
                    continue
                f.write(h['unique'] + '\n')
        with open(os.path.join(caseDir, 'case_'+str(i)+'.statement'), 'w') as f:
            for h in coverage.statement(hit):
                if h['module'] == 'Main':
                    continue
                f.write(h['unique'] + '\n')
        with open(os.path.join(caseDir, 'case_'+str(i)+'.expression'), 'w') as f:
            for h in coverage.expression(hit):
                if h['module'] == 'Main':
                    continue
                f.write(h['unique'] + '\n')
        with open(os.path.join(caseDir, 'case_'+str(i)+'.function'), 'w') as f:
            f.write('\n'.join([f for f in coverage.function(hit) if not f.startswith('Main.')]))

def saveAllCheckPoints(tickBoxes, funcNames):
    if not os.path.exists(os.path.join(WORK_DIR, 'test cases')):
        os.mkdir(os.path.join(WORK_DIR, 'test cases'))
    boxes = [h for m in tickBoxes for h in tickBoxes[m]]
    with open(os.path.join(WORK_DIR, 'test cases', 'all.branch'), 'w') as f:
        for h in coverage.branch(boxes):
            if h['module'] != 'Main':
                f.write(h['unique'] + '\n')
    with open(os.path.join(WORK_DIR, 'test cases', 'all.statement'), 'w') as f:
        for h in coverage.statement(boxes):
            if h['module'] != 'Main':
                f.write(h['unique'] + '\n')
    with open(os.path.join(WORK_DIR, 'test cases', 'all.expression'), 'w') as f:
        for h in coverage.expression(boxes):
            if h['module'] != 'Main':
                f.write(h['unique'] + '\n')
    with open(os.path.join(WORK_DIR, 'test cases', 'all.function'), 'w') as f:
        for m in funcNames:
            moduleName = haskell.getModuleName(os.path.join(WORK_DIR, 'src', m))
            for func in funcNames[m]:
                f.write(moduleName +'.'+func+'\n')

def coverageSumup(cases):
    tmpdir = fs.makeTempDir(WORK_DIR)
    shutil.rmtree(tmpdir)
    shutil.copytree(OBJ_DIR, tmpdir)

    try:
        results = runTests(tmpdir, cases)
        if results is None or not all(results):
            raise Exception('Some test case failed when generating coverage report')
        
        hpc.generateReport(os.path.join(tmpdir, 'test', 'testsuite.tix'), os.path.join(WORK_DIR, 'coverage'))
    finally:
        shutil.rmtree(tmpdir)

def replayMany(cases, mutant):
    def inner(tmpdir):
        shutil.rmtree(tmpdir)
        shutil.copytree(OBJ_DIR,tmpdir)
        shutil.copy(mutant['mutant'], os.path.join(tmpdir, mutant['original']))
    
        try:
            with subprocess.Popen(['cabal', 'build'], cwd=os.path.join(tmpdir, 'test')) as p:
                if p.wait() != 0:
                    return None
        except:
            return None
        result = runTests(tmpdir, cases)
        mutant['result'] = [(i,result[i]) for i in range(len(result))]
        return mutant
    return fs.withTempDir(inner)

def saveMutants(mutants):
    for mu in mutants:
        newLoc = os.path.join(WORK_DIR,'mutants',os.path.relpath(mu['mutant'], '/tmp/mutants'))
        if not os.path.exists(os.path.dirname(newLoc)):
            os.makedirs(os.path.dirname(newLoc))
        os.rename(mu['mutant'], newLoc)
        with open(newLoc+'.fn','w') as f:
            f.write(mu['module'] + '.' + mu['fn'])
        mu['mutant'] = newLoc
    return mutants

def executable(root):
    return os.path.join(root, 'test', 'dist', 'build', 'testsuite', 'testsuite')

def getTestCases():
    print(executable(os.path.join(WORK_DIR, 'src')))
    content = subprocess.check_output([executable(os.path.join(WORK_DIR, 'src')), '-l']).decode('utf8')
    result = []
    for m in re.finditer(r'Tests(.*)', content):
        result.append(m.group(1))
    return result

fs.makeEmptyDir(WORK_DIR)

shutil.copytree(srcLoc, os.path.join(WORK_DIR, 'src'))
hsfiles = [f for f in fs.findAllHsFiles(srcLoc) if not f.startswith('test/')]
for hs in hsfiles:
    haskell.preprocess(os.path.join(WORK_DIR, 'src', hs))

testCases = getTestCases()

funcNames = { hs: haskell.findFuncNames(os.path.join(WORK_DIR, 'src', hs)) for hs in hsfiles}
print('funcNames',funcNames)

fs.makeEmptyDir('/tmp/mutants')
mutants = []
for hs in hsfiles:
    print('generating mutants for', hs)
    mutants.extend(mucheck.generateFor(os.path.join(WORK_DIR, 'src'), os.path.join('/tmp/mutants'), hs))

mutants = util.randomizeBy(mutants, lambda x: x['type'])
print('total mutants', len(mutants))

tickBoxes = getTickBoxes()

hits = []
cases = []
for case in testCases:
    tmp = replay(tickBoxes, case)
    if tmp:
        hits.append(tmp)
        cases.append(case)
testCases = cases

print('saving hits')
saveHits(hits)

print('saveing checkpoints')
saveAllCheckPoints(tickBoxes, funcNames)

print('summing up coverage')
coverageSumup(cases)

mutants = paralle.do(functool.partial(replayMany, cases), mutants, 200)
print('left mutants', len(mutants))
saveMutants(mutants)

with open(os.path.join(WORK_DIR, 'result.csv'), 'w', newline='') as f:
    writer = csv.writer(f)
    writer.writerow(['mutant', 'case id', 'killed'])
    with open(os.path.join(WORK_DIR, 'result.csv'), 'w', newline='') as f:
        writer = csv.writer(f)
        writer.writerow(['mutant', 'case id', 'killed'])
        for mu in mutants:
            relativePath = os.path.relpath(mu['mutant'], os.path.join(WORK_DIR, 'mutants'))
            for r in mu['result']:
                caseId = r[0]
                caseSucc = r[1]
                writer.writerow([relativePath, caseId, 'no' if caseSucc else 'yes'])
