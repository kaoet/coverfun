import re
import os.path
import subprocess

def parseMIX(path, module):
    with open(path,'r') as f:
        s = f.read()
    boxes = []
    s = re.search(r'\[(\(.*\)|,)*\]$', s).group(0)
    for m in re.finditer(r'\((\d+):(\d+)-(\d+):(\d+),(\S*)\s(.*?)\)', s):
        boxes.append({
            'l1': int(m.group(1)),
            'c1': int(m.group(2)),
            'l2': int(m.group(3)),
            'c2': int(m.group(4)),
            'unique': os.path.basename(path) + m.group(0),
            'type': m.group(5),
            'info': m.group(6),
            'module': module
        })
    return boxes

def parseTIX(path):
    with open(path, 'r') as f:
        s = f.read()
    tixes = {}
    for m in re.finditer(r'TixModule "([^"]*)" \d+ \d+ (\[[0-9,]*\])', s):
        tixes[m.group(1)] = eval(m.group(2))
    return tixes

def removeModuleFromTix(path, modulename):
    with open(path,'r') as f:
        content = f.read()
    content = re.sub(r'TixModule "' + modulename + '" \d+ \d+ \[[0-9,]*\],', '', content)
    content = re.sub(r', TixModule "' + modulename + '" \d+ \d+ \[[0-9,]*\]', '', content)
    with open(path,'w') as f:
        f.write(content)

def getHitBoxes(mix, tix):
    hit = []
    for m in tix:
        if m == 'Test_':
            continue
        if m not in mix:
            raise Exception('Unknown module in tix', m)
        boxes = mix[m]
        idx = tix[m]
        for i in range(len(idx)):
            if idx[i] > 0:
                hit.append(boxes[i])
    return hit

def generateReport(path, destDir):
    direc = os.path.dirname(path)
    with subprocess.Popen(['/usr/bin/hpc', 'markup','--destdir=' + destDir, path], cwd=direc) as p:
        if p.wait()!=0:
            raise Exception('hpc markup failed')
    
