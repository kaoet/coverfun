import os.path
import os
import random
import shutil

def findAllHsFiles(directory):
    hsfiles = [f for f in os.listdir(directory) if f.endswith('.hs')]
    dirs = [d for d in os.listdir(directory) if os.path.isdir(os.path.join(directory, d))]
    for d in dirs:
        hsfiles.extend([os.path.join(d, f) for f in findAllHsFiles(os.path.join(directory, d))])
    return hsfiles

def findAllDirContaining(root, name):
    if len([f for f in os.listdir(root) if f==name]) > 0:
        return [root]
    dirs = [d for d in os.listdir(root) if os.path.isdir(os.path.join(root,d))]
    result = []
    for d in dirs:
        result.extend(findAllDirContaining(os.path.join(root, d), name))
    return result

def copyAll(files, src, dest):
    for f in files:
        directory = os.path.dirname(os.path.join(dest, f))
        if not os.path.exists(directory):
            os.makedirs(directory)
        shutil.copy(os.path.join(src, f), os.path.join(dest, f))

def makeTempDir(root):
    tmpdir = os.path.join(root,str(random.random()))
    while os.path.exists(tmpdir):
        tmpdir = os.path.join(root,str(random.random()))
    os.mkdir(tmpdir)
    return tmpdir

def makeTempFile(root):
    tmpdir = os.path.join(root,str(random.random()))
    while os.path.exists(tmpdir):
        tmpdir = os.path.join(root,str(random.random()))
    return tmpdir

def makeEmptyDir(path):
    remove(path)
    os.makedirs(path)

def remove(path):
    if os.path.isdir(path):
        shutil.rmtree(path)
    if os.path.isfile(path):
        os.remove(path)

def withTempDir(fn):
    tmpdir = makeTempDir('/tmp')
    ret = fn(tmpdir)
    remove(tmpdir)
    return ret
