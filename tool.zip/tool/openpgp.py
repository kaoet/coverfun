#!/usr/bin/env python3
import os.path
import shutil

import fs
import haskell
import mucheck
import ghc
import hpc
import coverage
import random
from multiprocessing import Pool, Value
import csv

WORK_DIR = '/home/kaoet/tmp'
OBJ_DIR = ''
srcLoc = '/home/kaoet/unit/openpgp-asciiarmor'

def compileOriginal(hsfiles):
    global OBJ_DIR
    OBJ_DIR = '/tmp/obj'
    if os.path.exists(OBJ_DIR):
        shutil.rmtree(OBJ_DIR)
    shutil.copytree(os.path.join(WORK_DIR, 'src'), OBJ_DIR)
    if not ghc.compile(OBJ_DIR, hsfiles, 'Main', hpc=True):
        raise Exception('Cannot compile original source code')

def getTickBoxes(hsfiles):
    modules = [haskell.getModuleName(os.path.join(WORK_DIR, 'src', hs)) for hs in hsfiles]
    return {m: hpc.parseMIX(os.path.join(OBJ_DIR, '.hpc', m+'.mix'), m) for m in modules}

def replay(tickBoxes, caseId):
    tmpdir = fs.makeTempDir('/tmp')
    shutil.rmtree(tmpdir)
    shutil.copytree(OBJ_DIR, tmpdir)
    
    try:
        [succ] = haskell.runTest(os.path.join(tmpdir, 'Main'), tmpdir, args=[str([caseId])])
        if not succ:
            raise Exception('original test suite not success', caseId, succ)
        
        tixes = hpc.parseTIX(os.path.join(tmpdir, 'Main.tix'))
        return hpc.getHitBoxes(tickBoxes, tixes)
    finally:
        shutil.rmtree(tmpdir)

def saveHits(hits):
    caseDir = os.path.join(WORK_DIR, 'test cases')
    os.mkdir(caseDir)
    
    for i in range(len(hits)):
        hit = hits[i]
        with open(os.path.join(caseDir, 'case_'+str(i)+'.branch'), 'w') as f:
            for h in coverage.branch(hit):
                if h['module'] == 'Main':
                    continue
                f.write(h['unique'] + '\n')
        with open(os.path.join(caseDir, 'case_'+str(i)+'.statement'), 'w') as f:
            for h in coverage.statement(hit):
                if h['module'] == 'Main':
                    continue
                f.write(h['unique'] + '\n')
        with open(os.path.join(caseDir, 'case_'+str(i)+'.function'), 'w') as f:
            f.write('\n'.join([f for f in coverage.function(hit) if not f.startswith('Main.')]))

def saveAllCheckPoints(tickBoxes, funcNames):
    if not os.path.exists(os.path.join(WORK_DIR, 'test cases')):
        os.mkdir(os.path.join(WORK_DIR, 'test cases'))
    boxes = [h for m in tickBoxes for h in tickBoxes[m]]
    with open(os.path.join(WORK_DIR, 'test cases', 'all.branch'), 'w') as f:
        for h in coverage.branch(boxes):
            if h['module'] != 'Main':
                f.write(h['unique'] + '\n')
    with open(os.path.join(WORK_DIR, 'test cases', 'all.statement'), 'w') as f:
        for h in coverage.statement(boxes):
            if h['module'] != 'Main':
                f.write(h['unique'] + '\n')
    with open(os.path.join(WORK_DIR, 'test cases', 'all.function'), 'w') as f:
        for m in funcNames:
            moduleName = haskell.getModuleName(os.path.join(WORK_DIR, 'src', m))
            for func in funcNames[m]:
                f.write(moduleName +'.'+func+'\n')

def coverageSumup(hsfiles, hits):
    tmpdir = fs.makeTempDir(WORK_DIR)
    shutil.rmtree(tmpdir)
    shutil.copytree(OBJ_DIR, tmpdir)

    try:
        results = haskell.runTest(os.path.join(tmpdir, 'Main'), tmpdir, args=[str(list(range(15)))])
        if results is None or not all(results):
            raise Exception('Some test case failed when generating coverage report')
        hpc.removeModuleFromTix(os.path.join(tmpdir, 'Main.tix'), 'Main')
        
        hpc.generateReport(os.path.join(tmpdir, 'Main.tix'), os.path.join(WORK_DIR, 'coverage'))
    finally:
        shutil.rmtree(tmpdir)

def replayMany(mutant):
    global g_progress
    global g_total
    print('REPLAYING MUTANT',g_progress.value,'of',g_total.value)
    g_progress.value+=1

    tmpdir = fs.makeTempDir('/tmp')
    shutil.rmtree(tmpdir)
    shutil.copytree(OBJ_DIR,tmpdir)
    shutil.copy(mutant['mutant'], os.path.join(tmpdir, mutant['original']))
    if os.path.exists(os.path.join(tmpdir, 'Main')):
        os.remove(os.path.join(tmpdir, 'Main'))
    
    try:
        if not ghc.compile(tmpdir, hsfiles, 'Main', hpc=True):
            return None
        return haskell.runTest(os.path.join(tmpdir, 'Main'), tmpdir, args=[str(list(range(15)))])
    finally:
        shutil.rmtree(tmpdir)

def initMap(progress, total):
    global g_progress
    global g_total
    g_progress = progress
    g_total = total

if os.path.exists(WORK_DIR):
    shutil.rmtree(WORK_DIR)
os.mkdir(WORK_DIR)

shutil.copytree(srcLoc, os.path.join(WORK_DIR, 'src'))
hsfiles = fs.findAllHsFiles(srcLoc)

funcNames = { hs: haskell.findFuncNames(os.path.join(WORK_DIR, 'src', hs)) for hs in hsfiles}
print('funcNames',funcNames)

mutants = []
for hs in hsfiles:
    if not hs.startswith('tests'):
        print('generating mutants for', hs)
        mutants.extend(mucheck.generateFor(os.path.join(WORK_DIR, 'src'), os.path.join(WORK_DIR, 'mutants'), hs))

compileOriginal(hsfiles)
tickBoxes = getTickBoxes(hsfiles)

hits = []
for i in range(15):
    hits.append(replay(tickBoxes, i))
saveHits(hits)
saveAllCheckPoints(tickBoxes, funcNames)
coverageSumup(hsfiles, hits)

total = Value('i', len(mutants), lock=False)
progress = Value('i', 0, lock=False)
with Pool(5,initializer=initMap, initargs=(progress, total)) as pool:
    results = pool.map(replayMany, mutants)

with open(os.path.join(WORK_DIR, 'result.csv'), 'w', newline='') as f:
    writer = csv.writer(f)
    writer.writerow(['mutant', 'tested function', 'case id', 'killed'])
    for i in range(len(results)):
        if not results[i]:
            continue
        for j in range(15):
            relativePath = os.path.relpath(mutants[i]['mutant'], os.path.join(WORK_DIR, 'mutants'))
            writer.writerow([relativePath,'N/A', j, 'no' if results[i][j] else 'yes'])
