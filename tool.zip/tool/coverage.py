def intersect(h1, h2):
    if (h1['l1'], h1['c1']) > (h2['l2'], h2['c2']):
        return False
    if (h1['l2'], h1['c2']) < (h2['l1'], h2['c1']):
        return False
    return True

def nest(s, b):
    return (b['l1'],b['c1']) <= (s['l1'], s['c1']) and (s['l2'],s['c2']) <= (b['l2'],b['c2'])

def statement(hit):
    funcBoxes = [h for h in hit if h['type']=='LocalBox' or h['type']=="TopLevelBox"]
    expBoxes = [h for h in hit if h['type']=='ExpBox']
    result = []
    
    funcBoxesFor = {}
    for fb in funcBoxes:
        if fb['module'] not in funcBoxesFor:
            funcBoxesFor[fb['module']] = []
        funcBoxesFor[fb['module']].append(fb)
        
    expBoxesFor = {}
    for eb in expBoxes:
        if eb['module'] not in expBoxesFor:
            expBoxesFor[eb['module']] = []
        expBoxesFor[eb['module']].append(eb)
    
    for expb in expBoxes:
        minFunc = None
        for funcb in funcBoxesFor[expb['module']]:
            if not nest(expb, funcb):
                continue
            if minFunc is None or nest(funcb, minFunc):
                minFunc = funcb
            elif not nest(minFunc, funcb) and intersect(funcb, minFunc):
                raise Exception('Intersecting function boxes')
        if not minFunc:
            raise Exception('ExprBox not embeded in function box')
        #print('minFunc for',expb['unique'], expb['l1'],expb['c1'],'is',minFunc['unique'],minFunc['l1'],minFunc['c1'])
        for expc in expBoxesFor[expb['module']]:
            if expc == expb:
                continue
            if nest(minFunc, expc):
                continue
            if not nest(expc, minFunc) and intersect(minFunc, expc):
                raise Exception('ExprBox intersect with minFunc')
            if nest(expb, expc):
                #print('found bigger box', expc['unique'], 'aroud', expb['unique'])
                break
        else:
            result.append(expb)
    return result

def branch(hit):
    ret = [h for h in hit if h['type']=='BinBox']
    ret.extend(statement(hit))
    return ret

def expression(hit):
    return hit

def function(hit):
    stmts = statement(hit)
    fnBoxes = [h for h in hit if h['type'] == 'TopLevelBox']
    
    fns = set()
    for stmt in stmts:
        for fn in fnBoxes:
            if fn['l1'] <= stmt['l1'] and stmt['l2'] <= fn['l2']:
                fns.add(fn['module']+'.'+fn['info'][2:-2]+'@'+str(fn['l1'])+':'+str(fn['c1']))
    return fns
