library("foreach")
library("parallel")
ROOT <- "~/Desktop/result10"
GROUP_COUNT <- 5
SIZES <- c(3,10,30,100,300)
ORACLE_COUNT <- 5
ORACLES <- c(0.2, 0.4, 0.6, 0.8, 1.0)
ASSERTION_COVERAGE_N <- 5
GROUP_SIZE <- 100
COLORS <- c(hsv(0, 1, 1), hsv(0.2,1,1), hsv(0.4,1,1), hsv(0.6,1,1), hsv(0.8,1,1))
prog.names <- list.dirs(ROOT, full.names = FALSE, recursive = FALSE)
printf <- function(...) cat(sprintf(...))

plot.cov.eff <- function(file.name, set.name, prog.names) {
	nrows <- length(prog.names)
	ncols <- GROUP_COUNT + 1
	pdf(file = file.path(ROOT, paste(set.name,".pdf",sep='')), width = 4, height = 16)
	par(mfrow = c(nrows, ncols), mar = c(0.3, 0.3, 0.3, 0.3), oma=c(2,3.2,1.3,0))
	
	correlation.lines <- length(prog.names) * (GROUP_COUNT + 1) * 2
	correlation.counter <- 0
	correlation <- data.frame(program = character(correlation.lines), 
		type = character(correlation.lines), size = character(correlation.lines), 
		tau = numeric(correlation.lines), stringsAsFactors = FALSE)

	row.idx <- 0
	all.brch <- c()
	all.expr <- c()
	all.eff <- c()
	for (prog.name in prog.names) {
		row.idx <- row.idx + 1
		#cat("processing", prog.name, "\n")
		
		prog.root <- file.path(ROOT, prog.name)
		if (!file.exists(file.path(prog.root, paste('coverage-effectiveness-', file.name,'-dots.csv',sep='')))) {
			break
		}
		dots <- read.csv(file.path(prog.root, paste('coverage-effectiveness-', file.name,'-dots.csv',sep='')), stringsAsFactors = FALSE)

		for (i in 1:GROUP_COUNT) {
			this.group.indices <- which(dots$group.id == i-1)
			#stmt.cov <- dots$statement[this.group.indices]
			brch.cov <- dots$branch[this.group.indices]
			expr.cov <- dots$expression[this.group.indices]
			eff <- dots$effectiveness[this.group.indices]

			#plot(stmt.cov, eff, col = 2, xaxt='n', yaxt='n', xlim = c(0, 1), ylim = c(0, 1), pch = ".")
			#points(brch.cov, eff, col = 3, pch = ".")
			plot(brch.cov, eff, col = 2, xaxt='n', yaxt='n', xlim = c(0, 1), ylim = c(0, 1), pch = ".")
			points(expr.cov, eff, col = 4, pch = ".")
			grid(nx=4,ny=4,lty="solid")
			
			if (i==1) {
				axis(2, at=c(0.5, 1), labels=c('0.5', '1'))
			}
			
			if (row.idx == length(prog.names)) {
				axis(1, at=c(0.5, 1), labels=c('0.5', '1'))
			}

			#correlation.counter <- correlation.counter + 1
			#correlation[correlation.counter, ] = list(prog.name, "statement", 
			#	SIZES[i], cor(stmt.cov, eff, method = "kendall"))
			correlation.counter <- correlation.counter + 1
			correlation[correlation.counter, ] = list(prog.name, "statement", 
				SIZES[i], cor(brch.cov, eff, method = "kendall"))
			correlation.counter <- correlation.counter + 1
			correlation[correlation.counter, ] = list(prog.name, "expression", 
				SIZES[i], cor(expr.cov, eff, method = "kendall"))
		}

		plot(as.vector(dots$branch), as.vector(dots$effectiveness), col = 2, 
			xlim = c(0, 1), ylim = c(0, 1), yaxt = "n", xaxt='n',
			ann = FALSE, pch = ".")
		#points(as.vector(dots$branch), as.vector(dots$effectiveness), col = 3, 
		#	pch = ".")
		points(as.vector(dots$expression), as.vector(dots$effectiveness), col = 4, 
			pch = ".")
		grid(nx=4,ny=4,lty="solid")
		
		if (row.idx == length(prog.names)) {
			axis(1, at=c(0.5, 1), labels=c('0.5', '1'))
		}

		correlation.counter <- correlation.counter + 1
		#correlation[correlation.counter, ] = list(prog.name, "statement", 
		#	"all", cor(as.vector(dots$statement), as.vector(dots$effectiveness), 
		#		method = "kendall"))
		correlation.counter <- correlation.counter + 1
		correlation[correlation.counter, ] = list(prog.name, "statement", 
			"all", cor(as.vector(dots$branch), as.vector(dots$effectiveness), 
				method = "kendall"))
		correlation.counter <- correlation.counter + 1
		correlation[correlation.counter, ] = list(prog.name, "expression", 
			"all", cor(as.vector(dots$expression), as.vector(dots$effectiveness), 
				method = "kendall"))
		printf("%s& %.2f& %.2f \\\\\n", prog.name,
				cor(as.vector(dots$branch), as.vector(dots$effectiveness), 
				method = "kendall"),cor(as.vector(dots$expression), as.vector(dots$effectiveness), 
				method = "kendall"))
		all.brch <- c(all.brch, dots$branch)
		all.expr <- c(all.expr, dots$expression)
		all.eff <- c(all.eff, dots$effectiveness)
	}
	
	for (i in 1:GROUP_COUNT) {
		mtext(SIZES[i], side=3, line=0, outer=TRUE, at=(i-0.5)/ncols)
	}
	mtext('all', side=3,line=0,outer=TRUE, at=(ncols-0.5)/ncols)
	for (i in 1:length(prog.names)) {
		mtext(prog.names[i], side=2, line=2, outer=TRUE, at=(length(prog.names) -i+0.5)/nrows)
	}

	dev.off()

	# save
	write.csv(correlation, row.names=FALSE, file = file.path(ROOT, paste(set.name,".csv",sep='')))
	
	printf("%.2f& %.2f \\\\\n", 
				cor(all.brch, all.eff, 
				method = "kendall"),cor(all.expr, all.eff, 
				method = "kendall"))
}

plot.oracle.eff <- function(set.name, prog.names) {
	pdf(file = file.path(ROOT, paste(set.name,".pdf",sep='')), width=9,height=6)
	par(mfrow = c(4, 6), mar = c(2, 0.5, 1, 0.5),oma=c(0,2,0,0))

	fig.idx <- 0
	all.oracle <- c()
	all.eff <- c()
	for (prog.name in prog.names) {
		row.idx <- floor(fig.idx / 6)
		col.idx <- fig.idx %% 6
		fig.idx <- fig.idx + 1
		#cat("processing", prog.name, "\n")
		
		prog.root <- file.path(ROOT, prog.name)
		if (!file.exists(file.path(prog.root, paste('oracle-size-effectiveness-dots.csv',sep='')))) {
			break
		}
		dots <- read.csv(file.path(prog.root, paste('oracle-size-effectiveness-dots.csv',sep='')), stringsAsFactors = FALSE)
		dots$oracle <- sapply(dots$oid, function(oid) {
			return(ORACLES[oid + 1])
		})
		
		if (col.idx == 0) {
			par(yaxt='s')
		} else {
			par(yaxt='n')
		}
		
		dots$fct <- factor(dots$oracle)
		plot(effectiveness ~ fct, data=dots,pch='.', xlab='', ylab='', main=prog.name)
		fit <- lm(effectiveness ~ oracle, data=dots)
		abline(fit, col="red")
		#for (i in 1:ORACLE_COUNT) {
		#	this.group.indices <- which(dots$oid == i-1)
		#	effectiveness <- dots$effectiveness[this.group.indices]
		#	size <- dots$size[this.group.indices]
		#	if (i==1) {
		#		plot(size, effectiveness,ylim=c(0,1), pch='.', col=2, xlab='', ylab='', main=prog.name)					#	}else if (i==2){
		#		points(size, effectiveness, pch='.',col=3)
		#	}else if (i==3) {
		#		points(size, effectiveness, pch='.',col=4)
		#	}else if (i==4) {
		#		points(size, effectiveness, pch='.',col=5)
		#	}else if (i==5) {
		#		points(size, effectiveness, pch='.',col=6)
		#	}
		#}
		#legend("bottomright", cex=0.8, pch=19, col = c(2, 3, 4), legend = c("Low", "Middle", "High"))
		legend("bottomright", cex=0.8, legend=paste("tau = ", round(cor(dots$oracle, dots$effectiveness, method='kendall'), 2), sep=''))
		
		all.oracle <- c(all.oracle, dots$oracle)
		all.eff <- c(all.eff, dots$effectiveness)
		printf("%s& %.2f \\\\\n", prog.name, cor(dots$oracle, dots$effectiveness, method='kendall'))
	}
	
	dev.off()
	printf("%.2f \\\\\n", cor(all.oracle, all.eff, method='kendall'))
}

plot.assertion.eff <- function(set.name, prog.names) {
	pdf(file = file.path(ROOT, paste(set.name,".pdf",sep='')), width=9,height=6)
	par(mfrow = c(4, 6), mar = c(2, 2, 1, 1))

	all.cov <- c()
	all.eff <- c()
	for (prog.name in prog.names) {
		#cat("processing", prog.name, "\n")
		prog.root <- file.path(ROOT, prog.name)
		if (!file.exists(file.path(prog.root, paste('assertion-coverage-effectiveness-dots.csv',sep='')))) {
			break
		}
		dots <- read.csv(file.path(prog.root, paste('assertion-coverage-effectiveness-dots.csv',sep='')), stringsAsFactors = FALSE)

		coverage.step <- max(dots$coverage) / ASSERTION_COVERAGE_N
		dots$fct <- factor(round(floor(dots$coverage / coverage.step) * coverage.step, 2))
		dots$cov <- floor(dots$coverage / coverage.step) + 1
		plot(effectiveness ~ fct, data=dots,pch='.', xlab='', ylab='', main=prog.name)
		fit <- lm(effectiveness ~ cov, data=dots)
		abline(fit, col="red")
		legend("bottomright", cex=0.8, legend=paste("tau = ", round(cor(dots$coverage, dots$effectiveness, method = "kendall"), 2), sep=''))
		printf("%s& %.2f \\\\\n", prog.name, cor(dots$coverage, dots$effectiveness, method = "kendall"))
		all.cov <- c(all.cov, dots$coverage)
		all.eff <- c(all.eff, dots$effectiveness)
	}
	dev.off()
	
	printf("%.2f", cor(all.cov, all.eff, method='kendall'))
}


#plot.cov.eff('raw', 'coverage-raw-effectiveness', prog.names)
#plot.cov.eff('normalized', 'coverage-normalized-effectiveness', prog.names)
#plot.oracle.eff('oracle-size-effectiveness', prog.names)
plot.assertion.eff('assertion-coverage-effectiveness', prog.names)
